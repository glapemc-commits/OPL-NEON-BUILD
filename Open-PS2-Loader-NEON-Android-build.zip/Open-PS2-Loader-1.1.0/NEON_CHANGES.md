# OPL NEON (base: Open PS2 Loader 1.1.0)

- Paleta neon padrão: fundo violeta, seleção ciano, detalhes rosa (Settings > UI > Reset Colors restaura).
- Relógio do console (RTC) no canto superior esquerdo. Liga/desliga em Settings > UI > "Show Clock".
- Pulo A–Z na lista de jogos: L3 = letra anterior, R3 = próxima letra.
- Versão exibida como v1.1.0-NEON-x; Makefile agora compila sem repositório git.

Build: ./build_neon.sh (Docker + ps2dev). Alterações marcadas com "NEON" no código.
