#!/bin/sh
# Compila o OPL NEON usando o toolchain oficial (ps2dev) via Docker.
# Requer: Docker instalado. Resultado: OPNPS2LD.ELF na pasta atual.
set -e
docker run --rm -v "$PWD":/src -w /src ps2dev/ps2dev:latest sh -c \
  "apk add --no-cache build-base git zip gawk python3 p7zip && make clean && make -j4"
ls -lh OPNPS2LD*.ELF 2>/dev/null || echo "Build terminou, mas o .ELF nao foi encontrado - veja o log acima."
